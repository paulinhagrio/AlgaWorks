package com.example.pgmoneyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PgmoneyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
