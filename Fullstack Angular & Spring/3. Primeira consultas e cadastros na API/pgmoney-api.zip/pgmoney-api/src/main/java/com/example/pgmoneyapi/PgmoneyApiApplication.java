package com.example.pgmoneyapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgmoneyApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PgmoneyApiApplication.class, args);
	}

}
